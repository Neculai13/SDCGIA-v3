"""Portable helpers for the SDCGIA Colab notebook; standard library until tokenization.

No model inference at import. The notebook passes the Unsloth encoder/predictor.
"""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import zipfile

QUESTIONS = {'origin': {'type': 'choice',
    'instructions': 'Stabilește originea textului: redactat de un om sau generat de inteligență artificială.',
    'criteria': {'human': 'Text redactat de un om.', 'ai': 'Text generat de inteligență artificială.'}}}


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def read_jsonl(path):
    return [json.loads(s) for s in Path(path).read_text(encoding='utf-8').splitlines() if s.strip()]


def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    temporary.replace(path)


def unpack_verified(bundle, destination, expected_manifest_sha):
    destination = Path(destination)
    with zipfile.ZipFile(bundle) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError('Duplicate names in bundle')
        raw = archive.read('bundle_manifest.json')
        if sha_bytes(raw) != expected_manifest_sha:
            raise ValueError('Wrong bundle manifest; use the ZIP delivered with this notebook')
        manifest = json.loads(raw)
        if set(names) != set(manifest['files']) | {'bundle_manifest.json'}:
            raise ValueError('Unexpected/missing bundle files')
        for name, digest in manifest['files'].items():
            part = PurePosixPath(name)
            if part.is_absolute() or '..' in part.parts or '\\' in name or ':' in name:
                raise ValueError('Unsafe bundle filename')
            content = archive.read(name)
            if sha_bytes(content) != digest:
                raise ValueError('Bundle hash mismatch: ' + name)
            path = destination.joinpath(*part.parts)
            path.parent.mkdir(parents=True, exist_ok=True)
            if path.exists() and path.read_bytes() != content:
                raise ValueError('Existing extracted file differs; choose a clean destination')
            if not path.exists():
                path.write_bytes(content)
        return manifest


def load_splits(directory):
    directory = Path(directory)
    data, metadata = {}, {}
    ids, source_split, group_split, text_split = set(), {}, {}, {}
    for split in ('train', 'calibration', 'test'):
        data[split] = read_jsonl(directory / 'data' / (split + '.jsonl'))
        metadata[split] = read_jsonl(directory / 'metadata' / (split + '.jsonl'))
        if len(data[split]) != len(metadata[split]):
            raise ValueError('Row/metadata count mismatch')
        for row, meta in zip(data[split], metadata[split]):
            if set(row) != {'state', 'questions', 'gold'} or row['questions'] != QUESTIONS:
                raise ValueError('Unexpected decision schema')
            if row['gold'] != {'origin': meta['label']} or meta['label'] not in ('human', 'ai'):
                raise ValueError('Invalid target')
            if not isinstance(row['state'], str) or not row['state'].strip():
                raise ValueError('Empty state')
            if sha_bytes(row['state'].encode('utf-8')) != meta['text_sha256']:
                raise ValueError('State hash mismatch')
            if meta['id'] in ids:
                raise ValueError('Duplicate record ID')
            ids.add(meta['id'])
            for value, lookup in ((meta['source_id'], source_split), (meta['group_id'], group_split),
                                  (' '.join(row['state'].casefold().split()), text_split)):
                previous = lookup.setdefault(value, split)
                if previous != split:
                    raise ValueError('Cross-split leakage')
    return data, metadata


def inspect_lengths(data, metadata, encode, max_length):
    details, summary = [], {}
    for split, rows in data.items():
        lengths = []
        for row, meta in zip(rows, metadata[split]):
            # Large encoding budget only counts tokens on CPU; it does not run the model.
            encoded = encode({'state': row['state'], 'questions': row['questions']}, 1_000_000)
            size = len(encoded.input_ids)
            if size >= 1_000_000:
                raise ValueError('Length audit budget reached')
            lengths.append(size)
            details.append({'split': split, 'id': meta['id'], 'tokens_full': size,
                            'over_context': size > max_length})
        ordered = sorted(lengths)
        summary[split] = {'rows': len(rows), 'max_tokens': max(lengths),
                          'median_tokens': ordered[len(ordered) // 2],
                          'p95_tokens': ordered[math.ceil(.95 * len(ordered)) - 1],
                          'over_context': sum(n > max_length for n in lengths)}
    return {'max_seq_length': max_length, 'splits': summary,
            'required_max_tokens': max(d['tokens_full'] for d in details),
            'over_context': sum(d['over_context'] for d in details), 'records': details}


def strict_items(data, metadata, tokenizer, model, fast_model, length_report):
    items = {}
    wanted = {(r['split'], r['id']): r['tokens_full'] for r in length_report['records']}
    for split, rows in data.items():
        built, report = fast_model.build_dataset(rows, tokenizer, model)
        if report.get('skipped') or len(built) != len(rows):
            raise RuntimeError('Unsloth omitted rows: ' + json.dumps(report))
        for index, item in enumerate(built):
            if item.get('row') != index:
                raise RuntimeError('Unexpected decision row alignment')
            if len(item['input_ids']) != wanted[split, metadata[split][index]['id']]:
                raise RuntimeError('Truncation or tokenizer/encoding mismatch; no training started')
        items[split] = built
    return items


def freeze_run(directory, configuration):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / 'run_config.json'
    if path.exists():
        if json.loads(path.read_text(encoding='utf-8')) != configuration:
            raise ValueError('Run configuration differs. Use a NEW RUN_NAME or restore old settings.')
    else:
        save_json(path, configuration)


def predict_saved(rows, metadata, predict, output, fingerprint):
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    identity = output.with_suffix('.identity.json')
    expected = {'fingerprint': fingerprint, 'ids': [m['id'] for m in metadata]}
    if identity.exists() and json.loads(identity.read_text(encoding='utf-8')) != expected:
        raise ValueError('Prediction cache belongs to a different model/data run')
    if output.exists() and not identity.exists():
        raise ValueError('Prediction output lacks provenance')
    save_json(identity, expected)
    saved = read_jsonl(output) if output.exists() else []
    if [r['id'] for r in saved] != expected['ids'][:len(saved)]:
        raise ValueError('Prediction cache is not an aligned prefix')
    for index in range(len(saved), len(rows)):
        answer = predict(rows[index]['state'], rows[index]['questions'])['origin']
        probabilities = answer['probabilities']
        if set(probabilities) != {'human', 'ai'} or any(not math.isfinite(float(p)) or not 0 <= p <= 1 for p in probabilities.values()):
            raise ValueError('Invalid decision probabilities')
        if abs(sum(probabilities.values()) - 1) > 1e-3:
            raise ValueError('Probabilities do not sum to one')
        row = {**metadata[index], 'p_ai': float(probabilities['ai']),
               'predicted_label': 'ai' if probabilities['ai'] >= .5 else 'human'}
        with output.open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + '\n')
            stream.flush()
            os.fsync(stream.fileno())
        saved.append(row)
        if (index + 1) % 25 == 0:
            print(f'Predicții salvate: {index + 1}/{len(rows)}', flush=True)
    return saved


def wilson(success, total):
    if not total:
        return None
    z, p = 1.95996398454, success / total
    denominator = 1 + z*z/total
    center = (p + z*z/(2*total)) / denominator
    half = z * math.sqrt(p*(1-p)/total + z*z/(4*total*total)) / denominator
    return [max(0, center-half), min(1, center+half)]


def metrics(rows):
    if not rows:
        raise ValueError('No predictions')
    tp = sum(r['label'] == 'ai' and r['predicted_label'] == 'ai' for r in rows)
    tn = sum(r['label'] == 'human' and r['predicted_label'] == 'human' for r in rows)
    fp = sum(r['label'] == 'human' and r['predicted_label'] == 'ai' for r in rows)
    fn = sum(r['label'] == 'ai' and r['predicted_label'] == 'human' for r in rows)
    result = {'n': len(rows), 'human_n': tn+fp, 'ai_n': tp+fn,
              'tp': tp, 'tn': tn, 'fp': fp, 'fn': fn, 'accuracy': (tp+tn)/len(rows),
              'false_positive_rate': fp/(tn+fp) if tn+fp else None,
              'false_negative_rate': fn/(tp+fn) if tp+fn else None,
              'ai_recall': tp/(tp+fn) if tp+fn else None,
              'fpr_wilson95': wilson(fp, tn+fp), 'ai_recall_wilson95': wilson(tp, tp+fn)}
    result['balanced_accuracy'] = ((tp/(tp+fn) + tn/(tn+fp))/2) if tp+fn and tn+fp else None
    result['brier'] = sum((r['p_ai'] - (r['label'] == 'ai'))**2 for r in rows)/len(rows)
    result['log_loss'] = -sum(math.log(max(1e-12, r['p_ai'] if r['label'] == 'ai' else 1-r['p_ai'])) for r in rows)/len(rows)
    buckets = defaultdict(list)
    for row in rows:
        confidence = max(row['p_ai'], 1-row['p_ai'])
        buckets[min(9, int(confidence*10))].append((confidence, row['label'] == row['predicted_label']))
    result['ece_10_equal_width_confidence_bins'] = sum(abs(sum(c for c, _ in bucket)-sum(ok for _, ok in bucket)) for bucket in buckets.values())/len(rows)
    return result


def grouped_metrics(rows):
    overall = metrics(rows)
    per_model = {}
    for model in sorted({r['model'] for r in rows if r['label'] == 'ai'}):
        generated = [r for r in rows if r['label'] == 'ai' and r['model'] == model]
        sources = {r['source_id'] for r in generated}
        human_pairs = [r for r in rows if r['label'] == 'human' and r['source_id'] in sources]
        per_model[model] = metrics(generated + human_pairs)
    return {'overall': overall, 'per_model_matched_sources': per_model,
            'threshold': .5, 'positive_class': 'ai',
            'notes': ['Per-model results use AI texts and their matched human sources, not all human test rows.',
                      'Wilson intervals describe binomial uncertainty and do not adjust for residual event dependence.',
                      'Metadata and labels are never passed into the predictor; only state and fixed questions.']}


def adapter_fingerprint(directory):
    directory = Path(directory)
    paths = sorted(p for p in directory.rglob('*') if p.is_file())
    if not paths:
        raise ValueError('Saved adapter directory is empty')
    return sha_bytes(json.dumps({p.relative_to(directory).as_posix(): sha_bytes(p.read_bytes()) for p in paths}, sort_keys=True).encode())
